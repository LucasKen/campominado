import java.awt.Graphics
import java.awt.Image
import java.awt.Rectangle

class Trash {
    var x: Int = (Math.random() * 720).toInt()
    var y: Int = 0
    private val trashImage: Image = loadImage("src/resources/lixo2.png").getScaledInstance(40, 40, Image.SCALE_SMOOTH)

    fun move() {
        y += 3 // Ajuste da velocidade vertical do lixo
    }

    fun draw(g: Graphics) {
        g.drawImage(trashImage, x, y, null)
    }

    val bounds: Rectangle
        get() = Rectangle(x, y, trashImage.getWidth(null), trashImage.getHeight(null))
}
