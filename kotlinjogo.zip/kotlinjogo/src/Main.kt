import javax.swing.*
import java.awt.*
import java.awt.event.ActionEvent
import java.awt.event.ActionListener
import java.awt.event.KeyEvent
import java.awt.event.KeyListener
import java.io.File
import javax.imageio.ImageIO
import java.awt.image.BufferedImage

class GamePanel : JPanel(), ActionListener, KeyListener {
    private val boat: Boat
    private val trashes = mutableListOf<Trash>()
    private val trashTimer: Timer
    private val gameTimer: Timer
    private val backgroundImage: Image

    init {

        backgroundImage = loadImage("src/resources/submar.png").getScaledInstance(800, 600, Image.SCALE_SMOOTH)
        boat = Boat()



        // Configurar temporizadores
        trashTimer = Timer(1500, ActionListener {
            trashes.add(Trash())
        })

        gameTimer = Timer(15, this)

        trashTimer.start()
        gameTimer.start()

        // Configurações do JPanel
        preferredSize = Dimension(800, 600)

        // Configurar KeyListener
        isFocusable = true
        addKeyListener(this)
    }

    override fun paintComponent(g: Graphics) {
        super.paintComponent(g)
        g.drawImage(backgroundImage, 0, 0, this)
        boat.draw(g)
        trashes.forEach { it.draw(g) }
    }

    override fun actionPerformed(e: ActionEvent) {
        boat.move()
        trashes.forEach { it.move() }
        checkCollisions()
        repaint()
    }

    private fun checkCollisions() {
        val iterator = trashes.iterator()
        while (iterator.hasNext()) {
            val trash = iterator.next()
            if (boat.bounds.intersects(trash.bounds)) {
                iterator.remove()
            } else if (trash.y > height) {
                iterator.remove()
            }
        }
    }

    override fun keyTyped(e: KeyEvent) {}

    override fun keyPressed(e: KeyEvent) {
        when (e.keyCode) {
            KeyEvent.VK_LEFT -> boat.dx = -5
            KeyEvent.VK_RIGHT -> boat.dx = 5
        }
    }

    override fun keyReleased(e: KeyEvent) {
        when (e.keyCode) {
            KeyEvent.VK_LEFT, KeyEvent.VK_RIGHT -> boat.dx = 0
        }
    }
}

//class Boat {
//    var x: Int = 400
//    var y: Int = 400 // Ajuste da posição vertical do barco
//    var dx: Int = 0
//    private val boatImage: Image = loadImage("src/resources/sub.png").getScaledInstance(80, 80, Image.SCALE_SMOOTH)
//
//    fun move() {
//        x += dx
//        if (x < 0) x = 0
//        if (x > 720) x = 720
//    }
//
//    fun draw(g: Graphics) {
//        g.drawImage(boatImage, x, y, null)
//    }
//
//    val bounds: Rectangle
//        get() = Rectangle(x, y, boatImage.getWidth(null), boatImage.getHeight(null))
//}

//class Trash {
//    var x: Int = (Math.random() * 720).toInt()
//    var y: Int = 0
//    private val trashImage: Image = loadImage("src/resources/lixo2.png").getScaledInstance(40, 40, Image.SCALE_SMOOTH)
//
//    fun move() {
//        y += 3 // Ajuste da velocidade vertical do lixo
//    }
//
//    fun draw(g: Graphics) {
//        g.drawImage(trashImage, x, y, null)
//    }
//
//    val bounds: Rectangle
//        get() = Rectangle(x, y, trashImage.getWidth(null), trashImage.getHeight(null))
//}

//class Game : JFrame() {
//    init {
//        title = "Coletor de Lixo Marinho"
//        defaultCloseOperation = JFrame.EXIT_ON_CLOSE
//        contentPane = GamePanel()
//        pack()
//        setLocationRelativeTo(null)
//        isVisible = true
//    }
//}

fun main() {
    SwingUtilities.invokeLater {
        Game()
    }
}

fun loadImage(path: String): BufferedImage {
    val imgURL = File(path).toURI().toURL()
    return ImageIO.read(imgURL)
}
