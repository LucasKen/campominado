import javax.swing.JFrame

class Game : JFrame() {
    init {
        title = "Coletor de Lixo Marinho"
        defaultCloseOperation = JFrame.EXIT_ON_CLOSE
        contentPane = GamePanel()
        pack()
        setLocationRelativeTo(null)
        isVisible = true
    }
}