import java.awt.Graphics
import java.awt.Image
import java.awt.Rectangle

class Logo {

    var x: Int = 200
    var y: Int = 150
    var dx: Int = 0
    private val logoImage: Image = loadImage("src/resources/logo.png").getScaledInstance(400, 400, Image.SCALE_SMOOTH)

    fun draw(g: Graphics) {
        g.drawImage(logoImage, x, y, null)
    }
    val bounds: Rectangle
        get() = Rectangle(x, y, logoImage.getWidth(null), logoImage.getHeight(null))
}