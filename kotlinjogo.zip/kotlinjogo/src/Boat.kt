import java.awt.Graphics
import java.awt.Image
import java.awt.Rectangle

class Boat {
    var x: Int = 400
    var y: Int = 400 // Ajuste da posição vertical do barco
    var dx: Int = 0
    private val boatImage: Image = loadImage("src/resources/sub.png").getScaledInstance(80, 80, Image.SCALE_SMOOTH)

    fun move() {
        x += dx
        if (x < 0) x = 0
        if (x > 720) x = 720
    }

    fun draw(g: Graphics) {
        g.drawImage(boatImage, x, y, null)
    }

    val bounds: Rectangle
        get() = Rectangle(x, y, boatImage.getWidth(null), boatImage.getHeight(null))
}