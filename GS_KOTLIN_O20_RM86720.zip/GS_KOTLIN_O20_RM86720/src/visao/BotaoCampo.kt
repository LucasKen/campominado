package visao

import modelo.Campo
import modelo.CampoEvento
import java.awt.Color
import java.awt.Font
import javax.swing.BorderFactory
import javax.swing.Icon
import javax.swing.JButton
import javax.swing.JLabel
import javax.swing.SwingConstants
import javax.swing.SwingUtilities
import javax.swing.UIManager

private val COR_BG_REVELADO = Color(25, 25, 112) // Azul Marinho Profundo
private val COR_BG_NAO_REVELADO = Color(30, 144, 255) // Azul Marinho Claro
private val COR_BG_MARCACAO = Color(0, 128, 128) // Verde Marinho
private val COR_BG_EXPLOSAO = Color(220, 20, 60) // Vermelho Carmesim
private val COR_TXT_VERMELHO = Color.RED
private val COR_TXT_AMARELO = Color.YELLOW
private val COR_TXT_VERDE = Color.GREEN
private val COR_TXT_BRANCO = Color.WHITE

private val iconeSacoLixo = UIManager.getIcon("OptionPane.errorIcon") // Ícone padrão de erro (exemplo)
private val iconeBandeira = UIManager.getIcon("OptionPane.warningIcon") // Ícone padrão de aviso (exemplo)

class BotaoCampo(private val campo: Campo) : JButton() {

    private val labelIcone = JLabel()

    init {
        font = Font("Arial", Font.BOLD, 14)
        foreground = COR_TXT_BRANCO
        background = COR_BG_NAO_REVELADO
        isOpaque = true
        border = BorderFactory.createBevelBorder(0)
        layout = null
        add(labelIcone)
        labelIcone.setBounds(0, 0, width, height)
        labelIcone.isVisible = false

        addMouseListener(MouseCliqueListener(campo, { it.abrir() }, { it.alterarMarcacao() }))

        campo.onEvento(this::aplicarEstilo)
    }

    private fun aplicarEstilo(campo: Campo, evento: CampoEvento) {
        when(evento) {
            CampoEvento.EXPLOSAO -> aplicarEstiloExplodido()
            CampoEvento.ABERTURA -> aplicarEstiloAberto()
            CampoEvento.MARCACAO -> aplicarEstiloMarcado()
            else -> aplicarEstiloPadrao()
        }

        SwingUtilities.invokeLater {
            repaint()
            validate()
        }
    }

    private fun aplicarEstiloExplodido() {
        background = COR_BG_EXPLOSAO
        labelIcone.icon = iconeSacoLixo
        labelIcone.isVisible = true
    }

    private fun aplicarEstiloAberto() {
        background = COR_BG_REVELADO
        border = BorderFactory.createLineBorder(Color.GRAY)

        text = if (campo.qtdeVizinhosMinados > 0) campo.qtdeVizinhosMinados.toString() else ""
        labelIcone.isVisible = false

        // Altera a cor da fonte de acordo com o número de vizinhos minados
        foreground = when (campo.qtdeVizinhosMinados) {
            1 -> COR_TXT_VERMELHO
            2 -> COR_TXT_AMARELO
            3 -> COR_TXT_VERDE
            4 -> COR_TXT_BRANCO
            else -> COR_TXT_BRANCO
        }
    }

    private fun aplicarEstiloMarcado() {
        background = COR_BG_MARCACAO
        labelIcone.icon = iconeBandeira
        labelIcone.isVisible = true
    }

    private fun aplicarEstiloPadrao() {
        background = COR_BG_NAO_REVELADO
        border = BorderFactory.createBevelBorder(0)
        text = ""
        labelIcone.isVisible = false
    }
}
