package visao
import java.io.File
import javax.sound.sampled.AudioSystem

class Jogo() {
    private val somMar = File("")
    private val somSacoLixo = File("CampoMinado/src/modelo/MP3/Garbage sound effect (256).mp3")
    private val somPing = File("")

    fun abrirCampo() {
        // Lógica para abrir o campo
        // Toca o som do mar ao abrir o campo
        playSound(somMar)
    }

    fun marcarBomba() {
        // Lógica para marcar a bomba
        // Toca o som de saco de lixo ao marcar a bomba
        playSound(somSacoLixo)
    }

    fun clicarCampo() {
        // Lógica para clicar em um campo
        // Toca o som de ping ao clicar em um campo
        playSound(somPing)
    }

    private fun playSound(file: File) {
        try {
            val clip = AudioSystem.getClip()
            val audioInputStream = AudioSystem.getAudioInputStream(file)
            clip.open(audioInputStream)
            clip.start()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
